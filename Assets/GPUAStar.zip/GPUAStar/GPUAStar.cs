using UnityEngine;

public class GPUAStar : MonoBehaviour
{
    public ComputeShader computeShader;
    public Vector3Int gridSize;
    public Vector3 cellSize;
    public float gridSpacing;
    public LayerMask obstacleLayer;
    public LayerMask groundLayer;
    public Transform target;

    private ComputeBuffer nodeBuffer;
    private ComputeBuffer openListBuffer;
    private ComputeBuffer closedListBuffer;
    private ComputeBuffer pathBuffer;

    private int nodeCount;

    struct Node {
        public Vector3 position;
        public Vector3 size;
        public float G;
        public float H;
        public float F;
        public bool reachable;
        public int openList;
        public int closedList;
        public Vector3 parent;
    }

    void Start()
    {
        InitGrid();
        GenerateGrid();
    }

    void InitGrid()
    {
        nodeCount = gridSize.x * gridSize.y * gridSize.z;
        nodeBuffer = new ComputeBuffer(nodeCount, sizeof(float) * 9 + sizeof(int) * 3);
        openListBuffer = new ComputeBuffer(nodeCount, sizeof(int));
        closedListBuffer = new ComputeBuffer(nodeCount, sizeof(int));
        pathBuffer = new ComputeBuffer(nodeCount, sizeof(int) * 3);
    }

    void GenerateGrid()
    {
        int kernel = computeShader.FindKernel("GenerateGrid");

        // Set shader parameters
        computeShader.SetInts("gridSize", gridSize.x, gridSize.y, gridSize.z);
        computeShader.SetFloat("gridSpacing", gridSpacing);
        computeShader.SetVector("cellSize", cellSize);
        computeShader.SetVector("worldPos", transform.position);

        // Set the buffers
        computeShader.SetBuffer(kernel, "gridNodes", nodeBuffer);

        // Dispatch the grid generation
        computeShader.Dispatch(kernel, gridSize.x / 8, gridSize.y / 8, gridSize.z / 8);
    }

    void AStarSearch()
    {
        int kernel = computeShader.FindKernel("AStarPathfinding");

        // Set up pathfinding kernel
        computeShader.SetVector("targetPos", target.position);
        computeShader.SetBuffer(kernel, "gridNodes", nodeBuffer);
        computeShader.SetBuffer(kernel, "openList", openListBuffer);
        computeShader.SetBuffer(kernel, "closedList", closedListBuffer);
        computeShader.SetBuffer(kernel, "path", pathBuffer);

        // Dispatch the pathfinding computation
        computeShader.Dispatch(kernel, 1, 1, 1); // Single thread for now, adjust based on need

        // Retrieve the path
        Vector3[] finalPath = new Vector3[nodeCount];
        pathBuffer.GetData(finalPath);
    }

    void OnDestroy()
    {
        nodeBuffer.Release();
        openListBuffer.Release();
        closedListBuffer.Release();
        pathBuffer.Release();
    }
}
