using System.Collections.Generic;
using UnityEngine;

struct Node
{
    public Vector3 Location;
    public Vector3 Size;
    public float G;
    public float H;
    public float F;
    public int id;
    public int parnetIdx;
    public int Reachable;
    public int Opened;
    public int Closed;
};

public class AStarCompute : MonoBehaviour
{
    [SerializeField] private ComputeShader computeShader;
    [SerializeField] private Transform target;

    [Header("Grid Settings")]
    [Range(0, 5)][SerializeField] private float gridSpacing;
    [SerializeField] private Vector3Int worldSize;
    [SerializeField] private Vector3 cellSize;
    [SerializeField] private LayerMask obstacleLayer;
    [SerializeField] private LayerMask groundLayer;

    [Space, Header("Debug Settings")]
    [SerializeField] private bool bDrawWorld;
    [SerializeField] private bool bDrawGrid;
    [SerializeField] private bool bDrawPath;
    [Range(0, 2)][SerializeField] private float drawNodeSize = 0.1f;

    [Space, Header("Compute Buffers")]
    private ComputeBuffer nodeBuffer;
    private ComputeBuffer unreachableNodeBuffer;
    private ComputeBuffer openListBuffer;
    private ComputeBuffer closedListBuffer;
    private ComputeBuffer pathBuffer;

    [Space, Header("Kernel Index")]
    private int InitGridKernel;
    private int UpdateGridKernel;
    private int SerachPathKernel;

    private bool isSearchDone;
    private bool isSearching;

    private Node[,,] grid;

    // private Node[] openNodes;
    // private Node[] closeNodes;


    void Start()
    {
        Init();
    }

    void Init()
    {
        // openNodes = new Node[worldSize.x * worldSize.y * worldSize.z];
        // closeNodes = new Node[worldSize.x * worldSize.y * worldSize.z];
        FindKernel();
        CreateInitialBuffers();
        SetBuffers();
        SetProperty();
        InitGrid();
    }

    void FindKernel()
    {
        InitGridKernel = computeShader.FindKernel("InitGrid");
        UpdateGridKernel = computeShader.FindKernel("UpdateGrid");
        SerachPathKernel = computeShader.FindKernel("SearchPath");
    }

    void CreateInitialBuffers()
    {
        int size = this.worldSize.x * this.worldSize.y * this.worldSize.z;
        int nodeSize = sizeof(float) * 9 + sizeof(int) * 5;
        nodeBuffer = new ComputeBuffer(size, nodeSize);
        unreachableNodeBuffer = new ComputeBuffer(size, sizeof(int));
        openListBuffer = new ComputeBuffer(size, nodeSize);
        closedListBuffer = new ComputeBuffer(size, nodeSize);
        pathBuffer = new ComputeBuffer(size, sizeof(int) * 3);
    }

    void SetBuffers()
    {
        SetComputeShaderBuffers(computeShader, nodeBuffer, "grid", InitGridKernel, UpdateGridKernel, SerachPathKernel);
        SetComputeShaderBuffers(computeShader, unreachableNodeBuffer, "unreachableNodes", UpdateGridKernel);
        SetComputeShaderBuffers(computeShader, openListBuffer, "openList", SerachPathKernel);
        SetComputeShaderBuffers(computeShader, closedListBuffer, "closedList", SerachPathKernel);
        SetComputeShaderBuffers(computeShader, pathBuffer, "path", SerachPathKernel);
    }

    void SetComputeShaderBuffers(ComputeShader computeShader, ComputeBuffer buffer, string id, params int[] kernels)
    {
        for (int i = 0; i < kernels.Length; i++)
        {
            computeShader.SetBuffer(kernels[i], id, buffer);
        }
    }

    void SetProperty()
    {
        computeShader.SetInts("worldSize", worldSize.x, worldSize.y, worldSize.z);
        computeShader.SetVector("worldPos", transform.position);
        computeShader.SetFloat("gridSpacing", gridSpacing);
        computeShader.SetVector("cellSize", cellSize);
        computeShader.SetVector("targetPos", target.position);

        //UpdateListProperty();
    }

    // void UpdateListProperty()
    // {
    //     computeShader.SetFloat("openListSize", openNodes.Count);
    //     computeShader.SetFloat("closedListSize", closeNodes.Count);
    // }

    void InitGrid()
    {
        int totalNodes = worldSize.x * worldSize.y * worldSize.z;
        int threadGroupSize = totalNodes / 2048;//Mathf.Min(worldSize.x, worldSize.y, worldSize.z);
        // Dispatch the compute shader to initialize the grid on the GPU
        computeShader.Dispatch(InitGridKernel, threadGroupSize, 1, 1);

        UpdateGrid();

        UpdateNodeReachability();
        computeShader.Dispatch(UpdateGridKernel, threadGroupSize, 1, 1);

        UpdateGrid();
    }

    void UpdateGrid()
    {
        int totalNodes = worldSize.x * worldSize.y * worldSize.z;
        Node[] flatGrid = new Node[totalNodes];
        nodeBuffer.GetData(flatGrid);

        // Now convert the flat array into a 3D array
        grid = new Node[worldSize.x, worldSize.y, worldSize.z];
        for (int x = 0; x < worldSize.x; x++)
        {
            for (int y = 0; y < worldSize.y; y++)
            {
                for (int z = 0; z < worldSize.z; z++)
                {
                    int index = x + y * worldSize.x + z * worldSize.x * worldSize.y;
                    grid[x, y, z] = flatGrid[index];
                }
            }
        }
    }

    void UpdateNodeReachability()
    {
        List<int> nodeIdx = new List<int>();

        for (int x = 0; x < worldSize.x; x++)
        {
            for (int y = 0; y < worldSize.y; y++)
            {
                for (int z = 0; z < worldSize.z; z++)
                {
                    Node node = grid[x, y, z];
                    // Check if this node is colliding with an obstacle
                    if (Physics.CheckBox(node.Location, cellSize, Quaternion.identity, obstacleLayer))
                    {
                        node.Reachable = 0; // Mark as unreachable if overlapping with an obstacle
                    }

                    if (Physics.Raycast(node.Location, Vector3.down, out RaycastHit hit, Mathf.Infinity, groundLayer))
                    {
                        if (Mathf.Abs(hit.point.y - node.Location.y) > 0.5f) // If the node is not on the ground
                        {
                            node.Reachable = 0;
                        }
                        else
                        {
                            node.Location = hit.point + new Vector3(0, cellSize.y, 0);
                        }
                    }
                    else
                    {
                        node.Reachable = 0;
                    }

                    if (Physics.CheckSphere(node.Location, 0.1f, groundLayer))
                    {
                        node.Reachable = 0;
                    }

                    if (node.Reachable == 0)
                    {
                        nodeIdx.Add(x + y * worldSize.x + z * worldSize.x * worldSize.y);
                    }
                }
            }
        }
        unreachableNodeBuffer.SetData(nodeIdx.ToArray());
    }


    void Update()
    {
        HandleInput();
        // openListBuffer.GetData(openNodes);
        // closedListBuffer.GetData(closeNodes);
        // if (isSearching && !isSearchDone)
        // {
        //     SearchPath();
        // }
    }

    void HandleInput()
    {
        if (Physics.CheckBox(transform.position, Vector3.one * 0.5f, Quaternion.identity, groundLayer) && Input.GetKeyDown(KeyCode.Space))
        {
            if (!isSearching)
            {
                //isSearching = true;
                for (int i = 0; i < 1; i++)
                {
                    SearchPath();
                }
                UpdateGrid();
            }

            // if (isSearchDone && path != null)
            // {
            //     StartCoroutine(FollowPath());
            // }
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            bDrawWorld = !bDrawWorld;
        }
        else if (Input.GetKeyDown(KeyCode.B))
        {
            bDrawGrid = !bDrawGrid;
        }
        else if (Input.GetKeyDown(KeyCode.P))
        {
            bDrawPath = !bDrawPath;
        }
    }

    void SearchPath()
    {
        Debug.Log("Searching Path");
        int totalNodes = worldSize.x * worldSize.y * worldSize.z;
        int threadGroupSize = totalNodes / 64;
        //int directionSize = 26;
        computeShader.Dispatch(SerachPathKernel, threadGroupSize, 1, 1);
    }


    void OnDrawGizmos()
    {
        if (bDrawWorld)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireCube(transform.position, (Vector3)worldSize * gridSpacing);
        }

        if (bDrawGrid)
        {
            if (grid != null)
            {
                for (int x = 0; x < worldSize.x; x++)
                {
                    for (int y = 0; y < worldSize.y; y++)
                    {
                        for (int z = 0; z < worldSize.z; z++)
                        {
                            Node node = grid[x, y, z];
                            // Gizmos.color = Color.white;
                            // Gizmos.DrawCube(node.Location, Vector3.one * drawNodeSize);
                            if (node.Reachable == 1)
                            {
                                Gizmos.color = Color.white;
                                if (node.Opened == 1)
                                {
                                    Gizmos.color = Color.green;
                                }
                                else if (node.Closed == 1)
                                {
                                    Gizmos.color = Color.blue;
                                }
                                Gizmos.DrawCube(node.Location, Vector3.one * drawNodeSize);
                            }
                        }
                    }
                }
            }
        }
    }
}
